<?php  
$Name=$_POST['Name'];
$Year=$_POST['Year'];
$Dept=$_POST['Department'];
$Email=$_POST['Email'];
$Phone=$_POST['Phone'];
$Domain=$_POST['Domain'];
echo "NAME:&nbsp;&nbsp;&nbsp;".$Name;
echo "<br>";
echo "YEAR:&nbsp;&nbsp;&nbsp;".$Year;
echo "<br>";
echo "DEPT :&nbsp;&nbsp;&nbsp;".$Dept;
echo "<br>";
echo "EMAIL: &nbsp;".$Email;
echo "<br>";
echo "PHONE:&nbsp;&nbsp;".$Phone;
echo "<br>";
echo "DOMAIN:".$Domain;
echo "<br>";
?>