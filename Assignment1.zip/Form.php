<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
<center><h1>Hope you are ready to make the web a better place!</h1></center>
<br>
<center><h1>Go ahead register for SRMKZILLA<h1></center>
</head>
<body background="Cool-Blue-Christmas-Background-Download.jpg">
	<center>
<form method="POST" action="Data.php">
	<p><h1>Name</h1></p>
	<input type="text" name="Name" placeholder="Enter Your Name" required>
	<br><br>
	<p><h1>Year</h1></p>
	<select name="Year" size="1">
  <option value="1st">1st</option>
  <option value="2nd">2nd</option>
  <option value="3rd">3rd</option>
  <option value="4th">4th</option>
</select>
<br><br>
<p><h1>Department</h1></p>
<input type="text" name="Department" placeholder="Department" required>
<br><br>
<p><h1>Email</h1></p>
<input type="Email" name="Email" placeholder="Email" required>
<br><br>
<p><h1>Phone Number</h1></p>
<input type="text" name="Phone" placeholder="Phone Number" required>
<br><br>
<p><h1>Applying for</h1></p>
<select name="Domain" size="1">
  <option value="Back End">Back End</option>
  <option value="Front End">Front End</option>
  <option value="Javascript">Javascript</option>
  <option value="Publicity">Publicity</option>
</select>
<br><br>
<input type="submit">
</form>
</center>
</body>
</html>